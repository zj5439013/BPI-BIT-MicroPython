# mpfshell - unit tests
2016-06-29, sw@kaltpost.de

This directory contains the unit test-suite (WIP) for the mpfshell. 
It uses [pytest](https://pytest.org/).

## Running the tests

Running the tests:

    export PYTHONPATH=$PWD/../..
    py.test -v
